import csv
import io
from flask import make_response

def createCSV(headers, csv_data):
    proxy = io.StringIO()
    writer = csv.DictWriter(proxy, fieldnames=headers)
    writer.writeheader()
    writer.writerows(csv_data)
    
    # Create a response with the CSV data.
    csv_response = make_response(proxy.getvalue())
    csv_response.headers['Content-Disposition'] = 'attachment; filename=core_configuration.csv'
    csv_response.headers['Content-Type'] = 'text/csv'
    return csv_response