from github import Github
import os

def gitPush(content):
    github_token = os.getenv('GITHUB_TOKEN')
    if github_token is None:
        github_token = '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'
        #github_token = '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' Ashwin
    g = Github(github_token)
    repo = g.get_repo('Logan-Chayet/Lab11PoC')
    #repo = g.get_repo('AshChanCUB/netdesign')

    file_path = 'ANSIBLE/config_requirements.csv'

    try:
        file = repo.get_contents(file_path, ref='main')
        repo.update_file(file_path, 'Update config_requirements.csv', content, file.sha, branch='main')
        print('File updated successfully.')
    except Exception as e:
        repo.create_file(file_path, 'Upload config_requirements.csv', content, branch='main')
        print('File created successfully.')
        
