from flask import Flask, render_template, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from runnConf import runConf
from diffConf import difConf
from validateIP import doubleCheck
from showCommands import show
from csvGenerate import createCSV
from gitAccess import gitPush
import pandas as pd

app = Flask(__name__)
app.secret_key = 'ashwin'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sshUsers.db'
db = SQLAlchemy(app)
#db model
class sshUsers(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device = db.Column(db.String(10), nullable=False)
    username = db.Column(db.String(50), nullable=False)
    password = db.Column(db.String(50), nullable=False)
    ip = db.Column(db.String(50), nullable=True)
    crypto = db.Column(db.Integer, nullable=True)
    domain = db.Column(db.String(50), nullable=True)
 
    def __repr__(self):
        return f'<SSHUser {self.device}>'

@app.route("/")
def homepage(): 
    return render_template("homepage.html")

@app.route('/edge', methods=['GET'])
def edge():
    return render_template('edge.html')

@app.route('/submit_edge_configuration', methods=['POST'])
def submit_edge_configuration():
    headers = [
        'Hostname', 'Interface Type', 'Interface Name', 'IPv4 Subnet', 'IPv6 Subnet',
        'OSPFv1 Enabled', 'OSPF Process ID', 'OSPF Area', 'OSPFv3 Enabled', 'BGPv4 enabled',
        'IPv4 Neighbor', 'remote AS', 'local AS', 'BGPv6 enabled', 'IPv6 neighbor',
        'Redistribution v4', 'Redistribution v6'
    ]

    form_data = request.form
    num_interfaces = len(form_data.getlist('interface_type[]'))
    csv_data = []

    for i in range(num_interfaces):
        row = {}
        for header in headers:
            form_key = header.replace(' ', '_').lower() + '[]'
            print('form_key')
            values = form_data.getlist(form_key)

            # Handle enabled and redistribution fields
            if 'enabled' in header.lower() or 'redistribution' in header.lower():
                row[header] = 'yes' if i < len(values) and values[i] == 'on' else 'no'
            # Regular text fields
            else:
                row[header] = values[i] if i < len(values) else ''
        csv_data.append(row)

    csv_response = createCSV(headers, csv_data)
    csv_content = csv_response.get_data(as_text=True)
    gitPush(csv_content)
    return render_template('edge.html')

    


@app.route('/core', methods=['GET'])
def core():
    return render_template('core.html')

@app.route('/submit_core_configuration', methods=['POST'])
def submit_core_configuration():
    headers = [
        'Hostname', 'Interface Type', 'Interface Name', 'IPv4 Subnet', 'IPv6 Subnet',
        'OSPFv1 Enabled', 'OSPF Process ID', 'OSPF Area', 'OSPFv3 Enabled'
    ]

    form_data = request.form
    num_interfaces = len(form_data.getlist('interface_type[]'))
    csv_data = []

    for i in range(num_interfaces):
        row = {}
        for header in headers:
            form_key = header.replace(' ', '_').lower() + '[]'
            values = form_data.getlist(form_key)

            # Handle enabled and redistribution fields
            if 'enabled' in header.lower() or 'redistribution' in header.lower():
                row[header] = 'yes' if i < len(values) and values[i] == 'on' else 'no'
            # Regular text fields
            else:
                row[header] = values[i] if i < len(values) else ''
        csv_data.append(row)

    csv_response = createCSV(headers, csv_data)
    csv_content = csv_response.get_data(as_text=True)
    gitPush(csv_content)
    return render_template('core.html')

@app.route('/server', methods=['GET'])
def server():
    return render_template('server.html')

@app.route('/submit_server_configuration', methods=['POST'])
def submit_server_configuration():
    headers = [
        'Hostname', 'Interface Type', 'Interface Name', 'IPv4 Subnet', 'Description', 'IPv6 Subnet',
        'OSPFv1 Enabled', 'OSPF Process ID', 'OSPF Area', 'OSPFv3 Enabled'
    ]

    form_data = request.form
    num_interfaces = len(form_data.getlist('interface_type[]'))
    csv_data = []

    for i in range(num_interfaces):
        row = {}
        for header in headers:
            form_key = header.replace(' ', '_').lower() + '[]'
            values = form_data.getlist(form_key)

            # Handle enabled and redistribution fields
            if 'enabled' in header.lower() or 'redistribution' in header.lower():
                row[header] = 'yes' if i < len(values) and values[i] == 'on' else 'no'
            # Regular text fields
            else:
                row[header] = values[i] if i < len(values) else ''
        csv_data.append(row)

    csv_response = createCSV(headers, csv_data)
    csv_content = csv_response.get_data(as_text=True)
    gitPush(csv_content)
    return render_template('server.html')


@app.route("/runn-conf", methods = ['POST', 'GET'])
def runnConf(): 

    devices = sshUsers.query.all()

    if request.method == "POST":
        dvc = request.form.get('device', '').strip()
        dvc_exist = db.session.query(sshUsers).filter_by(device = dvc).first()

        if dvc_exist:
            usr = dvc_exist.username
            pwd = dvc_exist.password
            ip = dvc_exist.ip

            try:
                msg = runConf(ip, usr, pwd)
            except Exception as e:
                msg = e

            return render_template("runningConfig.html", m=msg)
        else:
            return render_template("runningConfig.html", m="NA")
    return render_template("runningConfig.html", m=" ")

@app.route("/diff", methods = ['POST', 'GET'])
def diffConf(): 

    devices = sshUsers.query.all()

    if request.method == "POST":
        dvc = request.form.get('device', '').strip()
        dvc_exist = db.session.query(sshUsers).filter_by(device = dvc).first()

        if dvc_exist:
            usr = dvc_exist.username
            pwd = dvc_exist.password
            ip = dvc_exist.ip
            try:
                msg = difConf(ip, usr, pwd)
            except Exception as e:
                msg = e
            return render_template("diffComp.html", m=msg)
        else:
            return render_template("diffComp.html", m="NA")
    return render_template("diffComp.html", m=" ")


@app.route("/validIp", methods=['POST', 'GET'])
def validate(): 
    if request.method == "POST":
        IP = request.form.get('IPv4', '').strip()

        if IP:
            valid = doubleCheck(IP)
            if valid:
                return render_template("validateIP.html", val = "valid")
            else:
                return render_template("validateIP.html", val = "invalid")
        else:
            print("No IP entered")


    return render_template("validateIP.html", val = None)

@app.route("/show", methods=['POST', 'GET'])
def showComm():
    if request.method == "POST":
        proto = request.form.get('command').strip()
        dvc = request.form.get('device').strip()
        dvc_exist = sshUsers.query.filter_by(device=dvc).first()
    
        if dvc_exist:
            usr = dvc_exist.username
            pwd = dvc_exist.password
            ip = dvc_exist.ip
            int = request.form.get('interfaceType', '') + request.form.get('interfaceValue', '')

            try:
                output = show(proto, dvc, ip, usr, pwd, int)
            except Exception as e:
                output = str(e)
            return render_template("show.html", m=output)
        else:
            return render_template("show.html", m="Device not found.")
    return render_template("show.html", m=" ")

@app.errorhandler(404)
def errorpage(e):
    return("Big things coming, Stay tuned !!")
    
@app.route("/ssh", methods=['POST','GET'])
def sshDb():
    devices = sshUsers.query.all()
    print(request.method)
    headers = [
        'Device',
        'Username',
        'Password',
        'Management ip'
    ]
    csv_data = []
    if request.method == "POST":

        action = request.form.get('action')

        if action == 'clear_db':
            try:
                sshUsers.query.delete()
                db.session.commit()
                devices = []
                return render_template('sshDb.html', dev=devices)
            except Exception as e:
                print(e)
                return "Error clearing database"
               
        dvc = request.form.get('device', '').strip()
        usr = request.form.get('username', '').strip()
        pwd = request.form.get('password', '').strip()
        ip = request.form.get('ip', '').strip()

        if dvc and usr and pwd:
            dvc_exist = db.session.query(sshUsers).filter(sshUsers.device == dvc).scalar() is not None

            if not dvc_exist:
                new_sshUser = sshUsers(device=dvc, username=usr, password=pwd, ip=ip)
                try:
                    db.session.add(new_sshUser)
                    db.session.commit()
                    devices = sshUsers.query.all()
                except:
                    return "Error adding user"
            else:
                print("User already exist")
        else:
            print("No input entered. Value cannot be empty to submit")
        df = pd.DataFrame([(dev.device, dev.username, dev.password, dev.ip) for dev in devices], columns=headers)
        csv_content = df.to_csv(index=False)
        encoded_content = csv_content.encode('utf-8')
        gitPush(encoded_content)
    return render_template('sshDb.html', dev = devices)

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(host="localhost", port="8001",debug=True)
