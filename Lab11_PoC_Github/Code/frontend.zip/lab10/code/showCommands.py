from netmiko import ConnectHandler

def show(proto, dvc, ip, usr, pwd, int_type=None, int_value=None):
    conn = ConnectHandler(device_type="cisco_ios", host=ip, username=usr, password=pwd)
    try:
        if proto == "OSPF":
            output = conn.send_command('show run | sec router ospf')
        elif proto == "BGP":
            output = conn.send_command('show run | sec router bgp')
        elif proto == "INTERFACE":
            interface = f"{int_type}{int_value}"
            output = conn.send_command(f'show run interface {interface}')
    except Exception as e:
        output = f"An error occurred: {str(e)}"
    finally:
        conn.disconnect()

    return output


'''function updateInputFields() {
    var command = document.getElementById('commandSelect').value;

    if (command === 'OSPF') {
      additionalFields.innerHTML = `
        <div class="form-row">
          <label for="deviceName">Enter Device Name for OSPF:</label>
          <input type="text" id="deviceName" name="deviceName" placeholder="Device Name" required />
        </div>
      `;
    } else if (command === 'INTERFACE') {
      additionalFields.innerHTML = `
        <div class="form-row">
          <label for="deviceName">Enter Device Name for Interface:</label>
          <input type="text" id="deviceName" name="deviceName" placeholder="Device Name" required />
        </div>
        <div class="form-row">
          <label for="interfaceType">Select Interface Type:</label>
          <select id="interfaceType" name="interfaceType">
            <option value="fastethernet">FastEthernet</option>
            <option value="gigabitethernet">GigabitEthernet</option>
          </select>
          <input type="text" id="interfaceValue" name="interfaceValue" placeholder="Enter Interface Value" required />
        </div>
      `;
    }
  }

'''