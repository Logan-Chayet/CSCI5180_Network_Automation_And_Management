def process_snmp_data(data):
    # Process SNMP data here (e.g., calculate metrics, transform data)
    processed = {}
    for device, interfaces in data.items():
        processed[device] = {}
        for interface, metrics in interfaces.items():
            processed[device][interface] = {
                'traffic_in_kb': metrics['traffic_in'] / 1024,  # Convert to KB
                'traffic_out_kb': metrics['traffic_out'] / 1024  # Convert to KB
            }
    return processed